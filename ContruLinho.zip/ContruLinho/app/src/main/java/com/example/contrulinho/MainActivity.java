package com.example.contrulinho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
private ImageView Missao;
    private ImageView projeto;
    private ImageView visao;
    private ImageView Futuro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Missao.findViewById(R.id.IdMissao);
        Futuro.findViewById(R.id.IdFuturo);
        projeto.findViewById(R.id.IdProjeto);
        visao.findViewById(R.id.IdVisao);

            Missao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent Missao = new Intent(MainActivity.this, Missao.class);
                        startActivity(Missao);

                }
            });
        Futuro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Futuro = new Intent(MainActivity.this, com.example.contrulinho.Futuro.class);
                startActivity(Futuro);
            }
        });

        projeto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent projeto = new Intent(MainActivity.this, projeto.class);
                startActivity(projeto);

            }
        });
        visao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent visao = new Intent(MainActivity.this, visao.class);
                startActivity(visao);

            }
        });

    }
}
